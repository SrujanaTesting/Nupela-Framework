package pages1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LeftMenuPage extends AbstractPage{

	String sessionId;

	public LeftMenuPage() {
		PageFactory.initElements(getEventDriver(), this);

		String currentUrl = getEventDriver().getCurrentUrl();
		sessionId = "";
		if(currentUrl.contains("https://eip-tb.lntecc.com/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace("https://eip-tb.lntecc.com/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		getEventDriver().get("https://eip-tb.lntecc.com/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
	}

	
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
	
	@FindBy(how = How.LINK_TEXT, using = "Document")
	private WebElement eleDocument;
	
	@FindBy(how = How.LINK_TEXT, using = "Order Mgmt.")
	private WebElement eleOrderMgmt;
	
	@FindBy(how = How.LINK_TEXT, using = "Manufacturing Orders")
	private WebElement eleManufacturingOrders;
	
	public LeftMenuPage clickNavigation() {
		click(eleNavigation);
		return this;
	}
	
	public LeftMenuPage clickDocument() {
		click(eleDocument);
		return this;
	}
	
	public LeftMenuPage clickOrderMgmt() {
		click(eleOrderMgmt);
		return this;
	}
	
	public SearchManufacturingOrders clickManufacturingOrders() {
		click(eleManufacturingOrders);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new SearchManufacturingOrders();
	}

	
}
