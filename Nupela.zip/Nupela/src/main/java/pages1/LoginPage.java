package pages1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends AbstractPage{

	public LoginPage() {
		PageFactory.initElements(getEventDriver(), this);
	}


	@FindBy(how = How.ID, using = "txtUserName")
	private WebElement eleUName;

	@FindBy(how = How.ID, using = "txtPassword")
	private WebElement elePassword;

	@FindBy(how = How.ID, using = "btnLogin")
	private WebElement eleLogin;


	public LoginPage enterUserName(String data) {
		typeAndTab(eleUName, data);
		return this;
	}

	public LoginPage enterPassword(String data) {
		System.out.println(getAttributeText(elePassword, "value").trim());
		if(getAttributeText(elePassword, "value").trim().equals(""))
			type(elePassword, data);
		return this;
	}

	public LeftMenuPage clickLogin() {
		click(eleLogin);
		return new LeftMenuPage();
	}

}
