package pages1;

import base.WdMethods;
public class AbstractPage extends WdMethods{



}
