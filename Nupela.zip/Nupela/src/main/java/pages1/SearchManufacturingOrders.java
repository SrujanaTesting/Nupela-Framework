package pages1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SearchManufacturingOrders extends AbstractPage{

	String sessionId;

	public SearchManufacturingOrders() {
		PageFactory.initElements(getEventDriver(), this);
	}

	
	@FindBy(how = How.XPATH, using = "//span[@aria-owns='SearchFilter_OrderTypeCode_listbox']")
	private WebElement eleOrderType;
	

	
	public SearchManufacturingOrders selectOrderType(String type) {
		selectUsingText(eleOrderType,type);
		return this;
	}
	
	

	
}
