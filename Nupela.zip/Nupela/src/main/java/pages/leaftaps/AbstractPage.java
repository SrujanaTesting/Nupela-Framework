package pages.leaftaps;

import base.WdMethods;
public class AbstractPage extends WdMethods{



}
